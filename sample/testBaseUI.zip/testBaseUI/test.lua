
local id = Input:touchDown(415,1059,5,4,1)
print(id)
Thread:sleep(110)
Input:touchUp(id)
